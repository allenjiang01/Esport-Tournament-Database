# CPSC 304 Database Project

## Proposal

The purpose of this project is to create an E-sport competition database. Users will have access to a simple GUI to 
view current and upcoming tournaments, competitors, games, etc. Tournament organizers will be able to create new 
tournaments.

## User Stories
- As a user, I want to view ongoing tournaments and their associated game and competitors.
- As a user, I want to buy a ticket to attend a tournament.
- As an organizer, I want to create a new tournament for users to see.
